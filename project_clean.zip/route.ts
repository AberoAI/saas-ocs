// apps/frontend/src/app/api/trpc/route.ts
import { fetchRequestHandler } from "@trpc/server/adapters/fetch";
// Import runtime dari paket backend (pastikan dependensi workspace)
import { appRouter, createContext } from "@repo/backend";

const handler = (req: Request) =>
  fetchRequestHandler({
    endpoint: "/api/trpc",
    req,
    router: appRouter,
    createContext: async () => {
      // Ambil headers dari Request & teruskan ke createContext backend
      const headers = Object.fromEntries(req.headers);
      return createContext({ headers });
    },
  });

export { handler as GET, handler as POST };
