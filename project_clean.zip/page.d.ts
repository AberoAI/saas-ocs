export default function Home(): import("react").JSX.Element;
