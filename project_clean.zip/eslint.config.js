import { nextJsConfig } from "../../packages/eslint-config/next-js.js";

/** @type {import("eslint").Linter.Config} */
export default nextJsConfig;
