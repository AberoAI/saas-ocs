// apps/backend/src/index.ts
// Jangan gunakan type-only re-export; impor & expose supaya tsc memproses.
import { appRouter } from "./server/routers";

// (opsional) Import Redis helper agar PING tercetak saat start.
// Dibungkus try/catch agar tidak crash jika modul/konfigurasi belum ada.
try {
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  const { redis } = require("./lib/redis");
  void redis;
} catch {}

// ✅ Type export untuk konsumen (shared/frontend)
export type AppRouter = typeof appRouter;

// ✅ Runtime export agar frontend route bisa pakai router & context
export { appRouter } from "./server/routers";
export { createContext } from "./server/context";
