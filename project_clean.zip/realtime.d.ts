import { IncomingMessage } from "http";
import { Socket } from "net";
export declare function handleUpgrade(request: IncomingMessage, socket: Socket, head: Buffer): void;
//# sourceMappingURL=realtime.d.ts.map