// apps/backend/src/trpc/router.ts
// Bridge: re-export dari sumber kebenaran router di server/routers
export { appRouter } from "../server/routers";
export type { AppRouter } from "../server/routers";
