import { NextRequest, NextResponse } from "next/server";
export declare function rateLimitMiddleware(req: NextRequest): Promise<NextResponse<unknown>>;
//# sourceMappingURL=rateLimit.d.ts.map