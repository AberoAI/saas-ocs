import type { NextConfig } from "next";
declare const nextConfig: NextConfig;
export default nextConfig;
//# sourceMappingURL=next.config.d.ts.map