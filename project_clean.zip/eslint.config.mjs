import { config } from "../../eslint-config/react-internal.js";

/** @type {import("eslint").Linter.Config} */
export default config;
