export default function DashboardPage(): import("react").JSX.Element;
