// packages/shared/src/router.ts
// Type-only re-export agar konsumen (frontend) tidak menarik runtime backend.
export type { AppRouter } from "@repo/backend";
