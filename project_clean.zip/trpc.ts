// apps/backend/src/trpc/trpc.ts
import { initTRPC } from "@trpc/server";
import type { Context } from "./context";

const t = initTRPC.context<Context>().create();

export const router = t.router;
export const publicProcedure = t.procedure;

// Jika butuh middleware/role-based access di masa depan:
// export const middleware = t.middleware;
// export const protectedProcedure = t.procedure.use(authMiddleware);
