import { NextRequest, NextResponse } from "next/server";
export declare function middleware(req: NextRequest): Promise<NextResponse<unknown>>;
//# sourceMappingURL=auth.d.ts.map