export type { AppRouter } from "../../apps/backend/src/server/router";
//# sourceMappingURL=router.d.ts.map