import { middleware as authMiddleware } from "./src/middleware/auth";
export declare const middleware: typeof authMiddleware;
export declare const config: {
    matcher: string[];
};
//# sourceMappingURL=middleware.d.ts.map