// apps/backend/src/trpc/context.ts
import type { inferAsyncReturnType } from "@trpc/server";
// import { prisma } from "../db"; // ← kalau kamu punya prisma instance, tinggal aktifkan

/**
 * Context tRPC — tambahkan hal-hal yang kamu butuh (userId, tenantId, prisma, dsb).
 * Diset minimal agar tidak mengganggu bagian lain yang belum kamu minta ubah.
 */
export async function createContext() {
  // Contoh isian nanti:
  // const userId = ...;
  // const tenantId = ...;
  // return { userId, tenantId, prisma };

  return {};
}

export type Context = inferAsyncReturnType<typeof createContext>;
